package chocan.model;

/**
 * A ChocAn provider.
 * Author: [Part 5 author] - minimal model used by the accounting module.
 * NOTE: If the team already has a Provider class, delete this one and make
 * sure the team's class exposes the same getters.
 */
public class Provider {
    private final String number;   // 9 digits
    private String name;
    private String address;
    private String city;
    private String state;
    private String zip;

    public Provider(String number, String name, String address, String city, String state, String zip) {
        this.number = number;
        this.name = name;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    public String getNumber()  { return number; }
    public String getName()    { return name; }
    public String getAddress() { return address; }
    public String getCity()    { return city; }
    public String getState()   { return state; }
    public String getZip()     { return zip; }
}
