package chocan.model;

/**
 * A ChocAn member.
 * Author: [Part 5 author] - minimal model used by the accounting module.
 * NOTE: If the team already has a Member class, delete this one and make
 * sure the team's class exposes the same getters.
 */
public class Member {
    private final String number;   // 9 digits
    private String name;           // max 25 chars
    private String address;        // max 25 chars
    private String city;           // max 14 chars
    private String state;          // 2 letters
    private String zip;            // 5 digits

    public Member(String number, String name, String address, String city, String state, String zip) {
        this.number = number;
        this.name = name;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    public String getNumber()  { return number; }
    public String getName()    { return name; }
    public String getAddress() { return address; }
    public String getCity()    { return city; }
    public String getState()   { return state; }
    public String getZip()     { return zip; }
}
