package chocan.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * One service a provider recorded for a member (the "service record").
 * Author: [Part 5 author] - minimal model used by the accounting module.
 * The fee is NOT stored here; it is looked up from the Service directory
 * by service code when reports are produced.
 */
public class ServiceRecord {
    private final LocalDateTime recordedAt;  // when the computer received the data
    private final LocalDate serviceDate;     // date the service was provided
    private final String providerNumber;
    private final String memberNumber;
    private final String serviceCode;
    private final String comments;           // optional, max 100 chars

    public ServiceRecord(LocalDateTime recordedAt, LocalDate serviceDate, String providerNumber,
                         String memberNumber, String serviceCode, String comments) {
        this.recordedAt = recordedAt;
        this.serviceDate = serviceDate;
        this.providerNumber = providerNumber;
        this.memberNumber = memberNumber;
        this.serviceCode = serviceCode;
        this.comments = comments;
    }

    public LocalDateTime getRecordedAt() { return recordedAt; }
    public LocalDate getServiceDate()    { return serviceDate; }
    public String getProviderNumber()    { return providerNumber; }
    public String getMemberNumber()      { return memberNumber; }
    public String getServiceCode()       { return serviceCode; }
    public String getComments()          { return comments; }
}
