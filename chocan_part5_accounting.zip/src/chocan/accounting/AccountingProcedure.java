package chocan.accounting;

import chocan.model.Member;
import chocan.model.Provider;
import chocan.model.Service;
import chocan.model.ServiceRecord;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The weekly accounting procedure. Runs on demand (manager) or on schedule
 * (Friday midnight) and produces:
 *   - one report per member who received services,
 *   - one report per provider who gave services,
 *   - the accounts-payable summary report for the manager,
 *   - EFT data for every provider owed money.
 * Reports are returned as text and also written to the output folder.
 * Author: [Part 5 author]
 */
public class AccountingProcedure {
    private final AccountingDataSource data;
    private final ReportGenerator generator = new ReportGenerator();
    private final Path outputDir;

    public AccountingProcedure(AccountingDataSource data, String outputDir) {
        this.data = data;
        this.outputDir = Paths.get(outputDir);
    }

    // ---------------------------------------------------------------- lookups

    private Map<String, Member> memberMap() {
        Map<String, Member> map = new LinkedHashMap<>();
        for (Member m : data.getMembers()) map.put(m.getNumber(), m);
        return map;
    }

    private Map<String, Provider> providerMap() {
        Map<String, Provider> map = new LinkedHashMap<>();
        for (Provider p : data.getProviders()) map.put(p.getNumber(), p);
        return map;
    }

    private Map<String, Service> serviceMap() {
        Map<String, Service> map = new LinkedHashMap<>();
        for (Service s : data.getServices()) map.put(s.getCode(), s);
        return map;
    }

    /** Week covered by a run: the 7 days ending on (and including) weekEnd. */
    public static LocalDate weekStart(LocalDate weekEnd) {
        return weekEnd.minusDays(6);
    }

    /** Service records whose date of service falls in the week, oldest first. */
    private List<ServiceRecord> recordsInWeek(LocalDate start, LocalDate end) {
        List<ServiceRecord> result = new ArrayList<>();
        for (ServiceRecord r : data.getServiceRecords()) {
            if (!r.getServiceDate().isBefore(start) && !r.getServiceDate().isAfter(end)) result.add(r);
        }
        result.sort(Comparator.comparing(ServiceRecord::getServiceDate)
                .thenComparing(ServiceRecord::getRecordedAt));
        return result;
    }

    // ------------------------------------------------------- individual reports

    /** @return the report text, or null if no member has that number. */
    public String generateMemberReport(String memberNumber, LocalDate weekEnd) {
        Member m = memberMap().get(memberNumber);
        if (m == null) return null;
        LocalDate start = weekStart(weekEnd);
        List<ServiceRecord> mine = new ArrayList<>();
        for (ServiceRecord r : recordsInWeek(start, weekEnd)) {
            if (r.getMemberNumber().equals(memberNumber)) mine.add(r);
        }
        return generator.memberReport(m, mine, providerMap(), serviceMap(), start, weekEnd);
    }

    /** @return the report text, or null if no provider has that number. */
    public String generateProviderReport(String providerNumber, LocalDate weekEnd) {
        Provider p = providerMap().get(providerNumber);
        if (p == null) return null;
        LocalDate start = weekStart(weekEnd);
        List<ServiceRecord> mine = new ArrayList<>();
        for (ServiceRecord r : recordsInWeek(start, weekEnd)) {
            if (r.getProviderNumber().equals(providerNumber)) mine.add(r);
        }
        return generator.providerReport(p, mine, memberMap(), serviceMap(), start, weekEnd);
    }

    /** Per-provider totals for providers who gave at least one service that week. */
    public List<ProviderTotal> computeProviderTotals(LocalDate weekEnd) {
        LocalDate start = weekStart(weekEnd);
        Map<String, Provider> providers = providerMap();
        Map<String, Service> services = serviceMap();
        Map<String, ProviderTotal> totals = new LinkedHashMap<>();
        for (ServiceRecord r : recordsInWeek(start, weekEnd)) {
            Provider p = providers.get(r.getProviderNumber());
            if (p == null) continue;
            Service s = services.get(r.getServiceCode());
            BigDecimal fee = s == null ? BigDecimal.ZERO : s.getFee();
            ProviderTotal t = totals.get(p.getNumber());
            if (t == null) {
                t = new ProviderTotal(p);
                totals.put(p.getNumber(), t);
            }
            t.add(fee);
        }
        List<ProviderTotal> list = new ArrayList<>(totals.values());
        list.sort(Comparator.comparing(t -> t.getProvider().getName()));
        return list;
    }

    public String generateSummaryReport(LocalDate weekEnd) {
        return generator.summaryReport(computeProviderTotals(weekEnd), weekStart(weekEnd), weekEnd);
    }

    public List<EFTRecord> computeEFTRecords(LocalDate weekEnd) {
        List<EFTRecord> list = new ArrayList<>();
        for (ProviderTotal t : computeProviderTotals(weekEnd)) {
            list.add(new EFTRecord(t.getProvider().getName(), t.getProvider().getNumber(), t.getTotalFee()));
        }
        return list;
    }

    public String generateEFTReport(LocalDate weekEnd) {
        return generator.eftReport(computeEFTRecords(weekEnd), weekStart(weekEnd), weekEnd);
    }

    // ----------------------------------------------------------- full procedure

    /**
     * Runs the whole weekly procedure and writes every report to disk.
     * @return the summary report text (also saved) so the caller can show it
     */
    public String runWeeklyProcedure(LocalDate weekEnd) throws IOException {
        LocalDate start = weekStart(weekEnd);
        List<ServiceRecord> week = recordsInWeek(start, weekEnd);
        String stamp = weekEnd.toString();

        // Members with at least one service this week.
        Map<String, Boolean> memberSeen = new LinkedHashMap<>();
        Map<String, Boolean> providerSeen = new LinkedHashMap<>();
        for (ServiceRecord r : week) {
            memberSeen.put(r.getMemberNumber(), true);
            providerSeen.put(r.getProviderNumber(), true);
        }

        Files.createDirectories(outputDir);
        int memberFiles = 0;
        for (String number : memberSeen.keySet()) {
            String text = generateMemberReport(number, weekEnd);
            if (text != null) {
                save("member_" + number + "_" + stamp + ".txt", text);
                memberFiles++;
            }
        }
        int providerFiles = 0;
        for (String number : providerSeen.keySet()) {
            String text = generateProviderReport(number, weekEnd);
            if (text != null) {
                save("provider_" + number + "_" + stamp + ".txt", text);
                providerFiles++;
            }
        }
        String summary = generateSummaryReport(weekEnd);
        save("summary_" + stamp + ".txt", summary);
        save("eft_" + stamp + ".txt", generateEFTReport(weekEnd));

        return summary + "\nGenerated " + memberFiles + " member report(s), " + providerFiles
                + " provider report(s), 1 summary report and EFT data in: "
                + outputDir.toAbsolutePath() + "\n";
    }

    /** Saves any report text to the output folder. */
    public Path save(String fileName, String text) throws IOException {
        Files.createDirectories(outputDir);
        Path file = outputDir.resolve(fileName);
        Files.write(file, text.getBytes(StandardCharsets.UTF_8));
        return file;
    }
}
