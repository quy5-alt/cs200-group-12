package chocan.accounting;

import chocan.model.Member;
import chocan.model.Provider;
import chocan.model.Service;
import chocan.model.ServiceRecord;

import java.util.List;

/**
 * The only thing the accounting module needs from the rest of the system.
 * Have the team's data/repository class implement this interface (or write a
 * small adapter) and the accounting code works unchanged.
 * Author: [Part 5 author]
 */
public interface AccountingDataSource {
    List<Member> getMembers();
    List<Provider> getProviders();
    List<Service> getServices();
    List<ServiceRecord> getServiceRecords();
}
