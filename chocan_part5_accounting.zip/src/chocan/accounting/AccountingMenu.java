package chocan.accounting;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Command-line menu for accounting procedures and reports (manager/operator).
 * Hook into the main menu with:  new AccountingMenu(scanner, procedure).show();
 * Author: [Part 5 author]
 */
public class AccountingMenu {
    private final Scanner in;
    private final AccountingProcedure procedure;

    public AccountingMenu(Scanner in, AccountingProcedure procedure) {
        this.in = in;
        this.procedure = procedure;
    }

    public void show() {
        while (true) {
            System.out.println("\n=== Accounting Procedures & Reports ===");
            System.out.println("1. Run weekly accounting procedure (all reports + EFT)");
            System.out.println("2. Member report");
            System.out.println("3. Provider report");
            System.out.println("4. Summary report (manager)");
            System.out.println("5. EFT data");
            System.out.println("0. Back");
            System.out.print("Choice: ");
            String choice = in.nextLine().trim();
            try {
                switch (choice) {
                    case "1":
                        System.out.println(procedure.runWeeklyProcedure(askWeekEnd()));
                        break;
                    case "2": {
                        System.out.print("Member number: ");
                        String number = in.nextLine().trim();
                        print(procedure.generateMemberReport(number, askWeekEnd()), "member");
                        break;
                    }
                    case "3": {
                        System.out.print("Provider number: ");
                        String number = in.nextLine().trim();
                        print(procedure.generateProviderReport(number, askWeekEnd()), "provider");
                        break;
                    }
                    case "4":
                        System.out.println(procedure.generateSummaryReport(askWeekEnd()));
                        break;
                    case "5":
                        System.out.println(procedure.generateEFTReport(askWeekEnd()));
                        break;
                    case "0":
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (IOException e) {
                System.out.println("Could not write report files: " + e.getMessage());
            }
        }
    }

    private void print(String report, String kind) {
        if (report == null) System.out.println("No " + kind + " found with that number.");
        else System.out.println(report);
    }

    /** Asks for the last day of the week to report on (Enter = today). */
    private LocalDate askWeekEnd() {
        while (true) {
            System.out.print("Last day of the week (YYYY-MM-DD, Enter for today): ");
            String text = in.nextLine().trim();
            if (text.isEmpty()) return LocalDate.now();
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException e) {
                System.out.println("Please use the format YYYY-MM-DD.");
            }
        }
    }
}
