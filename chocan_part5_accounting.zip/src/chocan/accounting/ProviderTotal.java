package chocan.accounting;

import chocan.model.Provider;

import java.math.BigDecimal;

/**
 * One provider's weekly totals (used by the summary report and EFT data).
 * Author: [Part 5 author]
 */
public class ProviderTotal {
    private final Provider provider;
    private int consultations;
    private BigDecimal totalFee = BigDecimal.ZERO;

    public ProviderTotal(Provider provider) {
        this.provider = provider;
    }

    public void add(BigDecimal fee) {
        consultations++;
        totalFee = totalFee.add(fee);
    }

    public Provider getProvider()  { return provider; }
    public int getConsultations()  { return consultations; }
    public BigDecimal getTotalFee() { return totalFee; }
}
