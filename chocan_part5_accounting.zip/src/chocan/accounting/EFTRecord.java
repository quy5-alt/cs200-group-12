package chocan.accounting;

import java.math.BigDecimal;

/**
 * Electronic-funds-transfer data for one provider (name, number, amount).
 * In a real deployment this record would be sent to the bank; here it is
 * written to a file / printed.
 * Author: [Part 5 author]
 */
public class EFTRecord {
    private final String providerName;
    private final String providerNumber;
    private final BigDecimal amount;

    public EFTRecord(String providerName, String providerNumber, BigDecimal amount) {
        this.providerName = providerName;
        this.providerNumber = providerNumber;
        this.amount = amount;
    }

    public String getProviderName()   { return providerName; }
    public String getProviderNumber() { return providerNumber; }
    public BigDecimal getAmount()     { return amount; }
}
