package chocan.accounting;

import chocan.model.Member;
import chocan.model.Provider;
import chocan.model.Service;
import chocan.model.ServiceRecord;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * Stand-alone demo of the accounting module with sample data.
 *   java chocan.accounting.AccountingDemo          -> runs the weekly procedure
 *   java chocan.accounting.AccountingDemo menu     -> opens the interactive menu
 * Delete (or ignore) this class once the module is wired into the main app.
 * Author: [Part 5 author]
 */
public class AccountingDemo {

    static class SampleData implements AccountingDataSource {
        private final List<Member> members = Arrays.asList(
                new Member("100000001", "Alice Johnson", "12 Oak St", "Tuscaloosa", "AL", "35401"),
                new Member("100000002", "Bob Smith", "48 Elm Ave", "Northport", "AL", "35476"),
                new Member("100000003", "Carol White", "9 Pine Rd", "Tuscaloosa", "AL", "35405"));
        private final List<Provider> providers = Arrays.asList(
                new Provider("200000001", "Dr. Dana Lee", "1 Health Way", "Tuscaloosa", "AL", "35401"),
                new Provider("200000002", "Eli Dietitian", "77 Wellness Blvd", "Northport", "AL", "35476"),
                new Provider("200000003", "Fran Fitness", "5 Gym Ln", "Tuscaloosa", "AL", "35406"));
        private final List<Service> services = Arrays.asList(
                new Service("598470", "Dietitian Session", new BigDecimal("75.00")),
                new Service("883948", "Aerobics Class", new BigDecimal("30.50")),
                new Service("100200", "Counseling", new BigDecimal("120.00")));
        private final List<ServiceRecord> records = new ArrayList<>();

        SampleData(LocalDate weekEnd) {
            add(weekEnd.minusDays(1), "200000001", "100000001", "598470");
            add(weekEnd.minusDays(2), "200000001", "100000002", "100200");
            add(weekEnd.minusDays(3), "200000002", "100000001", "883948");
            add(weekEnd.minusDays(3), "200000002", "100000003", "883948");
            add(weekEnd.minusDays(8), "200000003", "100000002", "598470"); // outside the week
        }

        private void add(LocalDate date, String prov, String mem, String code) {
            records.add(new ServiceRecord(date.atTime(14, 5, 30), date, prov, mem, code, ""));
        }

        public List<Member> getMembers() { return members; }
        public List<Provider> getProviders() { return providers; }
        public List<Service> getServices() { return services; }
        public List<ServiceRecord> getServiceRecords() { return records; }
    }

    public static void main(String[] args) throws Exception {
        LocalDate today = LocalDate.now();
        AccountingProcedure procedure = new AccountingProcedure(new SampleData(today), "reports");
        if (args.length > 0 && args[0].equals("menu")) {
            new AccountingMenu(new Scanner(System.in), procedure).show();
        } else {
            System.out.println(procedure.runWeeklyProcedure(today));
            System.out.println(procedure.generateMemberReport("100000001", today));
            System.out.println(procedure.generateProviderReport("200000001", today));
            System.out.println(procedure.generateEFTReport(today));
        }
    }
}
