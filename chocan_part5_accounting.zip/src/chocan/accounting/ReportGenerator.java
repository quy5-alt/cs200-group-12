package chocan.accounting;

import chocan.model.Member;
import chocan.model.Provider;
import chocan.model.Service;
import chocan.model.ServiceRecord;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * Builds the text of every accounting report. Pure formatting: no file or
 * console I/O, so the output can be printed or saved by the caller.
 * Author: [Part 5 author]
 */
public class ReportGenerator {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
    private static final String LINE = repeat('=', 72);
    private static final String THIN = repeat('-', 72);

    private static String repeat(char c, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(c);
        return sb.toString();
    }

    private static String money(BigDecimal amount) {
        return String.format("$%,.2f", amount);
    }

    private static String header(String title, LocalDate start, LocalDate end) {
        return LINE + "\n" + title + "\nWeek: " + start.format(DATE) + " to " + end.format(DATE) + "\n" + LINE + "\n";
    }

    /** Member report: member info, then each service (date, provider name, service name). */
    public String memberReport(Member m, List<ServiceRecord> records, Map<String, Provider> providers,
                               Map<String, Service> services, LocalDate start, LocalDate end) {
        StringBuilder sb = new StringBuilder(header("CHOCAN MEMBER REPORT", start, end));
        sb.append("Name:    ").append(m.getName()).append('\n');
        sb.append("Number:  ").append(m.getNumber()).append('\n');
        sb.append("Address: ").append(m.getAddress()).append('\n');
        sb.append("City:    ").append(m.getCity()).append('\n');
        sb.append("State:   ").append(m.getState()).append('\n');
        sb.append("ZIP:     ").append(m.getZip()).append("\n\n");
        sb.append(String.format("%-14s %-27s %s%n", "Service Date", "Provider", "Service"));
        sb.append(THIN).append('\n');
        if (records.isEmpty()) {
            sb.append("(no services this week)\n");
        }
        for (ServiceRecord r : records) {
            Provider p = providers.get(r.getProviderNumber());
            Service s = services.get(r.getServiceCode());
            sb.append(String.format("%-14s %-27s %s%n", r.getServiceDate().format(DATE),
                    p == null ? "(unknown provider)" : p.getName(),
                    s == null ? "(unknown service)" : s.getName()));
        }
        return sb.toString();
    }

    /** Provider report: provider info, each consultation, totals. */
    public String providerReport(Provider p, List<ServiceRecord> records, Map<String, Member> members,
                                 Map<String, Service> services, LocalDate start, LocalDate end) {
        StringBuilder sb = new StringBuilder(header("CHOCAN PROVIDER REPORT", start, end));
        sb.append("Name:    ").append(p.getName()).append('\n');
        sb.append("Number:  ").append(p.getNumber()).append('\n');
        sb.append("Address: ").append(p.getAddress()).append('\n');
        sb.append("City:    ").append(p.getCity()).append('\n');
        sb.append("State:   ").append(p.getState()).append('\n');
        sb.append("ZIP:     ").append(p.getZip()).append("\n\n");
        sb.append(String.format("%-11s %-19s %-20s %-10s %-8s %10s%n",
                "Svc Date", "Received", "Member", "Member #", "Code", "Fee"));
        sb.append(THIN).append('\n');
        BigDecimal total = BigDecimal.ZERO;
        int count = 0;
        for (ServiceRecord r : records) {
            Member m = members.get(r.getMemberNumber());
            Service s = services.get(r.getServiceCode());
            BigDecimal fee = s == null ? BigDecimal.ZERO : s.getFee();
            String name = m == null ? "(unknown member)" : m.getName();
            if (name.length() > 20) name = name.substring(0, 20);
            sb.append(String.format("%-11s %-19s %-20s %-10s %-8s %10s%n",
                    r.getServiceDate().format(DATE), r.getRecordedAt().format(DATE_TIME), name,
                    r.getMemberNumber(), r.getServiceCode(), money(fee)));
            total = total.add(fee);
            count++;
        }
        if (count == 0) sb.append("(no services this week)\n");
        sb.append(THIN).append('\n');
        sb.append("Total consultations: ").append(count).append('\n');
        sb.append("Total fee for week:  ").append(money(total)).append('\n');
        return sb.toString();
    }

    /** Manager summary report: every provider owed money, plus grand totals. */
    public String summaryReport(List<ProviderTotal> totals, LocalDate start, LocalDate end) {
        StringBuilder sb = new StringBuilder(header("CHOCAN ACCOUNTS PAYABLE SUMMARY REPORT", start, end));
        sb.append(String.format("%-27s %-11s %14s %14s%n", "Provider", "Number", "Consultations", "Fee Total"));
        sb.append(THIN).append('\n');
        int consultations = 0;
        BigDecimal grand = BigDecimal.ZERO;
        for (ProviderTotal t : totals) {
            sb.append(String.format("%-27s %-11s %14d %14s%n", t.getProvider().getName(),
                    t.getProvider().getNumber(), t.getConsultations(), money(t.getTotalFee())));
            consultations += t.getConsultations();
            grand = grand.add(t.getTotalFee());
        }
        if (totals.isEmpty()) sb.append("(no services this week)\n");
        sb.append(THIN).append('\n');
        sb.append("Total providers who provided services: ").append(totals.size()).append('\n');
        sb.append("Total number of consultations:         ").append(consultations).append('\n');
        sb.append("Overall fee total:                     ").append(money(grand)).append('\n');
        return sb.toString();
    }

    /** EFT data: provider name, number, amount to transfer. */
    public String eftReport(List<EFTRecord> records, LocalDate start, LocalDate end) {
        StringBuilder sb = new StringBuilder(header("CHOCAN EFT DATA", start, end));
        sb.append(String.format("%-27s %-11s %14s%n", "Provider", "Number", "Amount"));
        sb.append(THIN).append('\n');
        if (records.isEmpty()) sb.append("(no transfers this week)\n");
        for (EFTRecord e : records) {
            sb.append(String.format("%-27s %-11s %14s%n", e.getProviderName(), e.getProviderNumber(),
                    money(e.getAmount())));
        }
        return sb.toString();
    }
}
